package com.example.controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.entity.HostPojo;

@RestController
public class HostController {


	@PostMapping(path = "/bfhl")
	public HostPojo insertcd(@PathVariable String[] numberarr) {
		HostPojo e = new HostPojo();
		e.setIs_success(true);
		e.setUser_id("karishma_patil_27111997");
		e.setEmail("patilkarishma511@gmail.com");
		e.setRoll_number("210945920044");

		String []arrnum = new String[numberarr.length];
		String []arralpha = new String[numberarr.length];
		int x=0,z=0;
		for(int i=0; i<numberarr.length; i++) {
			String checknum = numberarr[i];
			if(Character.isDigit(checknum.charAt(i))){
				arrnum[x] = numberarr[i];
				x++;
			}
			else {
				arralpha[z] = numberarr[i];
				z++;
			}
		}
		e.setNumbers(arrnum);
		e.setAlphabets(arralpha);
		return e;
	}
}
